package mayday.interpreter.rinterpreter.core;

import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.swing.AbstractAction;

import mayday.core.Mayday;
import mayday.core.tasks.AbstractTask;
import mayday.core.tasks.BarOnlyProgressComponent;
import mayday.core.tasks.ProgressStateChangedListener;
import mayday.core.tasks.ProgressStateEvent;
import mayday.core.tasks.TextAreaProgressComponent;
import mayday.interpreter.rinterpreter.RDefaults;


/**
 * An RJob creates all temporary files needed for the execution
 * of R, and executes R.
 * Use the run method to run R.
 * 
 * 
 * @author Matthias
 *
 */
public class RJob
{
    public static final int CANCELED=-1;
    public static final int OK=0;
    
	private File rinputFile;
	private File tmpSource;
	private File result;
	private File batch;
	private File error;
	private RSettings settings;
	private Date preExecutionDate;
	
	private int returnValue=-1;
    private int exitState=RJob.CANCELED;
    private PrintWriter logWriter;
	
	
	/**
	 * Creates a new RJob with the related files.
	 * 
	 * @param settings
	 * @param m
	 * @param pl
	 */
	public RJob(RSettings settings)
	{
		this.settings=settings;
    }
	
	/**
	 * @return error file, containing the content of Rs StdErr output.<br>
	 * The returned file does not exist if it had length 0 (if no error output was
	 * produced).
	 * 
	 */
	public File getError()
	{
		return error;
	}
	
	/**
	 * @return the temporary R-input-file that contains the data structures.
	 */
	public File getRInputFile()
	{
		return this.rinputFile;
	}
	
	/**
	 * @return the temporary source file
	 */
	public File getTmpSource()
	{
		return this.tmpSource;
	}
	
	
	/**
	 * @return the temporary result file
	 */
	public File getResult()
	{
		return this.result;
	}  
	

	/**
	 * Run the RJob:
	 * Execute the shell script,
	 * wait for execution (this can take some time with
	 * respect to the complexity of the given R source code),
	 * delete the error file, if it is empty,
	 * and delete the temporary files if <tt>deleteTmpFiles</tt> is set.
	 * 
	 * @return the exit value of the r process
	 * @throws Exception
	 */
	public int run() throws Exception
	{
        RProcessStateMonitor stateMonitor=new RProcessStateMonitor(settings);
        
        try
	    {
            //stateMonitor creates a pid12345 file for dynamic
            //correspondence with R
	        stateMonitor.start();
	        
	        this.preExecutionDate=new Date(System.currentTimeMillis());
	        
	        AbstractTask fileTask=new AbstractTask(
                "Create temporary files", 
                //true,  //standAlone?
                BarOnlyProgressComponent.class)
            {
                protected synchronized void initialize()
                {}

                protected void doWork()
                {
                    createFiles();
                }
                
                public void createFiles()
                {   
                    fireIndeterminateChanged(true);
                    fireValueChanged(100);
                    //create the files
                    try
                    {                
                        //create mastertable file
                        rinputFile=TempFileFactory.createRInputFile(settings);
                        fireValueChanged(200);
                        
                        //create temporary source file
                        tmpSource=TempFileFactory.createTempSourceFile(
                            settings,
                            RJob.this
                        );
                        fireValueChanged(400);
                        
                        //create output file
                        result=TempFileFactory.createResultFile(settings);
                        fireValueChanged(600);
                        
                        //create error file
                        error=TempFileFactory.createErrorFile(settings);
                        fireValueChanged(700);
                        
                        // create batch file
                        batch=TempFileFactory.createBatch(
                            settings,
                            RJob.this
                        );
                        fireValueChanged(1000);
                                               
                    }catch(IOException ex)
                    {
                        ex.printStackTrace();
                        throw new RuntimeException(
                            "Could not create the files needed for execution.\n\n"
                            + ex.getMessage()
                        );
                    }catch(Exception ex)
                    {
                        ex.printStackTrace();
                        throw new RuntimeException(ex.getMessage());        
                    }finally
                    {                    
                        getDialog().setVisible(false);
                    }
                }
            };
            Mayday.TASK_MANAGER.addTask(fileTask);
            fileTask.start();
            fileTask.getDialog().setVisible(true);
            
            
            try
	        {
	            File f=new File(this.settings.getLogFilename());
	            if(f.length()==0)
	            {
	                PrintWriter w=new PrintWriter(new FileWriter(f));
	                w.println(RDefaults.R_LOGFILE_HEADER);
	                w.close();
	            }else //test if this is really a RForMayday logfile
	            {
	                BufferedReader rd=new BufferedReader(new FileReader(f));
	                String firstLine=rd.readLine();
	                rd.close();
	                if(!firstLine.equals(RDefaults.R_LOGFILE_HEADER))
	                {
	                    throw new IOException("Not a log-file!");
	                }
	            }
	            
	            logWriter=new PrintWriter(
	                new FileWriter(
	                    f,
	                    true  //append?
	                ),
	                true //autoflush?
	            );
	        }catch(Exception ex)
	        {
	            logWriter=new PrintWriter(System.out,true);
	        }
	        
	        
	        long timeFrom=System.currentTimeMillis();
	        this.settings.setBeginTimeStamp(timeFrom);
	        logWriter.println(
	            ""+new Date(timeFrom)
	            +": R session started with \n\t"+settings.toString().replaceAll("\\n","\n\t")
	        );
	        
	        
            
	        //Doing real, hard work :) 
            RTask task=new RTask();       
	        stateMonitor.addProgressStateChangedListener(task);
            task.addTaskFinishedListener(stateMonitor);
	        Mayday.TASK_MANAGER.addTask(task);
            settings.setProbeLists(null);
            task.start();  
            if (this.settings.silentRunning) {  //fb: new case for runInternal action 
            	task.waitFor();
            } else {
            	task.getDialog().setVisible(true); //this waits because the shown dialog is modal!!!
            }
            this.exitState=task.getValue();
            
            
	        if(!this.settings.getStatusFile().delete())
	        {
	            this.settings.getStatusFile().deleteOnExit();
	        }
	        
	        long timeTo=System.currentTimeMillis();
	        this.settings.setEndTimeStamp(timeTo);
	        logWriter.print(
	            ""+new Date(timeTo)+": "
	            + "(" + ((timeTo-timeFrom)/1000.0) +" sec.)" 
	            + " R session "
	            
	        );
	        
	        if(task.getValue()==RJob.CANCELED)
	        {
	            logWriter.println(
	                "canceled."	       
	            );
	            returnValue=task.getValue();
	            
	        }else if(error.length()==0)
	        {
	            error.delete();
	            error=null;
	            logWriter.println("finished successfully.");
	        }else
	        {
	            logWriter.println(
	                "finished with errors or warnings." +
	                (this.settings.deleteOutputFiles()!=RDefaults.TempFiles.DEL_YES?
	                        "":" See file '"+error.getName()+"'.")			
	            );
	        }		
	        logWriter.close();
	        
	        return this.returnValue;
            
	    }catch(Exception ex)
	    {
	        stateMonitor.setFinished();
	        throw ex;
	    }
	}
	
	public boolean isCanceled()
	{
	    return this.exitState==RJob.CANCELED;
	}

	public File[] getInputFiles()
	{
		File[] f=
		{
			rinputFile,
			tmpSource,
			batch
		};
		return f;
	}
	
	public File[] getOutputFiles()
	{
		File[] f=
		{
			result,
			error
		};
		return f;		
	}
	
	
	/**
	 * @return
	 */
	public Date getPreExecutionDate()
	{
		return preExecutionDate;
	}

    /**
     * @return Returns the returnValue.
     */
    public int getExitValue()
    {
        return returnValue;
    }
    
       
    
    private class RTask
    extends AbstractTask
    implements ProgressStateChangedListener
    {
        private String cmd;
        private Process p=null;
        private CancelAction cancelAction;
        private OkAction okAction;
        private int returnState=RJob.OK;
        
        public RTask()
        {
            super(
                "R Process", //name
                //true, //open stand-alone dlg
                TextAreaProgressComponent.class
            );
        }

        /* (non-Javadoc)
         * @see mayday.core.tasks.AbstractTask#initialize()
         */
        protected synchronized void initialize()
        {
            cancelAction=new CancelAction();
            okAction=new OkAction();
            addAction(cancelAction); 
            addAction(okAction);
        }
      
        /**
         * Start the R task.
         * 
         * @see mayday.core.tasks.AbstractTask#doWork()
         */
        protected void doWork()
        {         
            try
            {                
                cmd=RDefaults.COMMAND_INTERPRETER+" "+batch.getAbsolutePath();
                logWriter.println("executing the cmd: "+cmd);
                
                p=Runtime.getRuntime().exec(cmd);
                Thread.yield();
                
                //wait for finishing R
                returnValue=p.waitFor();
                
                cancelAction.setEnabled(false);
                okAction.setEnabled(true);
            }catch(Exception e)
            {
                logWriter.println(e.getStackTrace());
            }                 
        }
        
        /**
         * Forcibly kills the R process. This can be called by the
         * user, if the R process seems to hang.
         * <p>
         * 
         * The process is killed either with the
         * <code>kill -9</code> command (on unix-like systems)
         * or <code>tskill</code> (on Windows XP).
         *
         * If there is a system with other <em>kill</em>-commands,
         * imediately call me!
         */
        private void killRProcess()
        {
            //this forcibly kills on WindowsXP and Unix-derivates
            //TODO: test killing on Win2k/NT
            try
            {
                //read the pid file
                File pidfile=new File(
                    settings.getWorkingDir(),
                    RDefaults.PID_FILENAME
                );
                BufferedReader rd=new BufferedReader(new FileReader(
                    pidfile
                ));
                String pid=rd.readLine().trim();
                rd.close();
                
                //execute the killer with the given pid
                Process kill=Runtime.getRuntime().exec(
                    RDefaults.KILL_PROCESS+pid
                );
                kill.waitFor();
                
                if(!pidfile.delete())
                {
                    pidfile.deleteOnExit();
                }                
            }catch(Throwable t)
            {
                if(RDefaults.DEBUG) t.printStackTrace();
                
            }                    
        }
        
        private class CancelAction extends AbstractAction
        {
            public CancelAction()
            {
                super(RDefaults.ActionNames.CANCEL);
            }
            public void actionPerformed(ActionEvent arg0)
            {
                //really kill this process!!!
                killRProcess();
                returnState=RJob.CANCELED;
                getDialog().setVisible(false);
                fireTaskFinished();
            }

        }
        
        private class OkAction extends AbstractAction
        {
            public OkAction()
            {
                super(RDefaults.ActionNames.OK);
                setEnabled(false);
            }
            public void actionPerformed(ActionEvent arg0)
            {
                returnState=RJob.OK;
                getDialog().setVisible(false);
            }

        }
        
        /**
         * The value of this tasks object is the value
         * supplied by the pressed action.
         * 
         * @return
         */
        public int getValue()
        {
            return returnState;
        }

        /* (non-Javadoc)
         * @see mayday.core.tasks.ProgressStateChangedListener#progressStateChanged(mayday.core.tasks.ProgressStateEvent)
         */
        public void progressStateChanged(ProgressStateEvent event)
        {
            if(event.get(ProgressStateEvent.ACTIONS.MESSAGE)!=null)
            {
                this.stateEvent.put(
                    ProgressStateEvent.ACTIONS.MESSAGE,
                    event.get(ProgressStateEvent.ACTIONS.MESSAGE)
                );
            }
            
            int value=((Integer)event.get(ProgressStateEvent.ACTIONS.VALUE)).intValue();
            if(value<0)
            {
                this.stateEvent.put(ProgressStateEvent.ACTIONS.INDETERMINATE,new Boolean(true));
            }else
            {
                this.stateEvent.put(ProgressStateEvent.ACTIONS.INDETERMINATE,new Boolean(false));
            }
            this.stateEvent.put(
                ProgressStateEvent.ACTIONS.VALUE,
                new Integer(value)
            );  
            
            fireProgressStateChanged();
        }   
    }
}
