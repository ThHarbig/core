package mayday.interpreter.rinterpreter.core;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.prefs.Preferences;

import mayday.core.MasterTable;
import mayday.core.mi.MIOGroup;
import mayday.core.mi.MIOSelection;
import mayday.core.mi.MIOType;
import mayday.interpreter.rinterpreter.RDefaults;

/**
 * Class that collects the setting.
 * 
 * @author Matthias
 *
 */
public class RSettings 
{
	public static int DEL_ASK=RDefaults.TempFiles.DEL_ASK;
	public static int DEL_NO=RDefaults.TempFiles.DEL_NO;
	public static int DEL_YES=RDefaults.TempFiles.DEL_YES;	
    
    private boolean active = true;
	
    private String rbinary;
    private String workingdir;
    private String logfile;
    private RSource source;
    private int deleteOutputFiles=RDefaults.TempFiles.DEL_ASK;
    private int deleteInputFiles=RDefaults.TempFiles.DEL_ASK;
    private int plotType=RDefaults.TempFiles.PNG_PLOT;
    private boolean showPlots=true;
    private long beginTimeStamp;
    private long endTimeStamp=-1;
    private File statusFile;
    
    public boolean silentRunning = false; // (fb) true if used by RPlugin.runInternal 
    
    private MasterTable masterTable;
    private List probeLists;
    private List returnList=null;
    private List<MIOGroup<? extends MIOType>> miolist=null;
    private List<MIOSelection> mioSelection=null;
    private Map<String, Integer> mioTypes=null;
    private Map<Integer, String> mioTypes2=null;
    
    //private Semaphore semaphore=new Semaphore(0);
    
//    public void releaseWaiters()
//    {
//        semaphore.release();
//    }
    
//    public void waitFor()
//    {
//        try
//        {
//            this.semaphore.acquire();
//            
//        }catch(InterruptedException ex)
//        {;}
//    }

    public List<MIOSelection> getMIOSelection()
    {
        if(this.mioSelection==null)
        {
            this.mioSelection=new ArrayList<MIOSelection>();
        }
        return this.mioSelection;
    }
    
    public List<MIOGroup<? extends MIOType>> getMIOGroups()
    {
        if(this.miolist==null)
        {
            this.miolist=new ArrayList<MIOGroup<? extends MIOType>>();
        }
        return this.miolist;
    }

    public long getBeginTimeStamp()
    {
        return beginTimeStamp;
    }
 
    public void setBeginTimeStamp(long beginTimeStamp)
    {
        this.beginTimeStamp = beginTimeStamp;
    }
    public String getBinary()
    {
        return this.rbinary;
    }

    public void setBinary(String filename)
    {
        this.rbinary=filename;
    }

    public String getWorkingDir()
    {
        return this.workingdir;
    }

    public void setWorkingDir(String directory)
    {
        this.workingdir=directory;
    }
    
    public void setLogFilename(String filename)
    {
    	this.logfile=filename;
    }
    
    public String getLogFilename()
    {
    	return this.logfile;
    }

    public void setSource(RSource src)
    {
        this.source=src;
    }

    public RSource getSource()
    {
        return source;
    }
    
    public String toString()
    {
    	return
    	"R-binary:  ............"+this.rbinary+"\n"+
    	"WorkingDir:  .........."+this.workingdir+"\n"+
    	"LogFile:  ............."+this.logfile+"\n"+
    	"Selected Function: ...."+this.source.getDescriptor()+"\n"+
    	"Function call: ........"+this.source.functionString();
    }
    
    /*
    public void setFunction(RFunction fun)
    {
    	this.function=fun;
    }//*/
    
    /*
    public RFunction getFunction()
    {
    	return this.function;
    }//*/
    
	/**
	 * @return
	 */
	public int deleteInputFiles()
	{
		return this.deleteInputFiles;
	}

	/**
	 * @param b
	 */
	public void setDeleteInputFiles(int i)
	{
		this.deleteInputFiles=i;
	}

	/**
	 * @return
	 */
	public int deleteOutputFiles()
	{
		return this.deleteOutputFiles;
	}

	/**
	 * @param b
	 */
	public void setDeleteOutputFiles(int i)
	{
		this.deleteOutputFiles=i;
	}
	
	/**
	 *  This method is used to create an instance of RSettings to be
	 *  invoked in a quiet session of the <i>R for Mayday</i> interface.
	 *  That means all GUI capabilities of this plug-in are turned off.
	 *  <br>
	 *  This method is needed when the R-interpreter should be invoked
	 *  within other <i>Mayday</i> plug-ins. 
	 * 
	 *  @param  rsource An object of type RSource.
	 *  @return Rettings A new instance of class RSettings initialized by
	 *          the given RSource object and the settings stored in the
	 *          <i>R for Mayday</i> plug-in's preferrences.
	 */
	public static RSettings createInitializedInstance(RSource rsource)
	{
		Preferences prefs=RDefaults.getPrefs();
		RSettings settings=new RSettings();
		
		settings.setBinary(
			prefs.get(RDefaults.Prefs.BINARY_KEY,null)
		);
		settings.setLogFilename(
			prefs.get(RDefaults.Prefs.LOGFILE_KEY,null)
		);
		
		settings.setSource(rsource);  
		
		settings.setDeleteInputFiles(
			prefs.getInt(
				RDefaults.Prefs.DELETEINPUTFILES_KEY,
				RSettings.DEL_YES
			)
		);
		settings.setDeleteOutputFiles(
			prefs.getInt(
				RDefaults.Prefs.DELETEOUTPUTFILES_KEY,
				RSettings.DEL_YES
			)
		);
		
		settings.setWorkingDir( // (fb) this was missing
			prefs.get(
					RDefaults.Prefs.WORKINGDIR_KEY,
					RDefaults.Prefs.WORKINGDIR_DEFAULT)
			)
		);
		
		settings.setPlotType(
		    prefs.getInt(
		        RDefaults.Prefs.PLOT_TYPE_KEY,
		        RDefaults.TempFiles.PNG_PLOT
		    )
		);
		
		return settings;
	}

    /**
     * @return Returns the plotType.
     */
    public int getPlotType()
    {
        return plotType;
    }
    /**
     * @param plotType The plotType to set.
     */
    public void setPlotType(int plotType)
    {
        this.plotType = plotType;
    }
    /**
     * @return Returns the showPlots.
     */
    public boolean isShowPlots()
    {
        return showPlots;
    }
    /**
     * @param showPlots The showPlots to set.
     */
    public void setShowPlots(boolean showPlots)
    {
        this.showPlots = showPlots;
    }
    public File getStatusFile()
    {
        return statusFile;
    }
    public void setStatusFile(File pidFile)
    {
        this.statusFile = pidFile;
    }
    public void setEndTimeStamp(long endTimeStamp)
    {
        this.endTimeStamp = endTimeStamp;
    }
    public long getDuration()
    {
        return this.endTimeStamp<0? 
                -1:
                this.endTimeStamp-this.beginTimeStamp;
    }

    public MasterTable getMasterTable()
    {
        return masterTable;
    }
    public void setMasterTable(MasterTable masterTable)
    {
        this.masterTable = masterTable;
    }
    public List getProbeLists()
    {
        return probeLists;
    }
    public void setProbeLists(List probeLists)
    {
        this.probeLists = probeLists;
    }
    public List getReturnList()
    {
        return returnList;
    }
    public void setReturnList(List returnList)
    {
        this.returnList = returnList;
    }
    
    
    public Map<String, Integer> getMioTypes()
    {
        return mioTypes;
    }
    synchronized public void setMioTypes(Map<String, Integer> mioTypes)
    {
        this.mioTypes = mioTypes;
        this.mioTypes2=new HashMap<Integer, String>();
        for(String s:mioTypes.keySet())
        {
            this.mioTypes2.put(this.mioTypes.get(s),s);
        }
    }
    public Map<Integer, String> getMioTypes2()
    {
        return this.mioTypes2;
    }
    
    public boolean isActive()
    {
        return active;
    }
    
    public void activate()
    {
        active = true;
    }
    
    public void inactivate()
    {
        active = false;
    }
    
}

