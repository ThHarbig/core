/*
 * Created on 21.11.2004
 */
package mayday.interpreter.rinterpreter.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.event.EventListenerList;

import mayday.core.tasks.ProgressStateChangedListener;
import mayday.core.tasks.ProgressStateEvent;
import mayday.core.tasks.TaskFinishedEvent;
import mayday.core.tasks.TaskFinishedListener;
import mayday.interpreter.rinterpreter.RDefaults;

/**
 * @author Matthias
 *
 */
public class RProcessStateMonitor
extends Thread
implements TaskFinishedListener
{
    private File infoExchangeFile;
    private EventListenerList eventListenerList;
    
    private ProgressStateEvent event=null;
    private RSettings settings;
    private String oldMessage=null;
    private boolean finished;
    
    RProcessStateMonitor(RSettings settings) throws IOException
    {
        super("R - Process State Monitor");
        this.eventListenerList=new EventListenerList();
        this.settings=settings;
        this.settings.setStatusFile(
            File.createTempFile("status","",new File(this.settings.getWorkingDir()))
        );  
        this.finished=false;
    }
    
    public void run()
    {
        try
        {
            while(!finished)
            {
                try
                {
                    BufferedReader rd=new BufferedReader(
                        new FileReader(this.settings.getStatusFile())    
                    );
                    String tmp=rd.readLine();
                    rd.close();
                    
                    if(tmp!=null && !tmp.equals(this.oldMessage)) // (fb) checking for null here
                    {
                       this.oldMessage=tmp; 
                       
                       String[] splits=tmp.split(";",2);
                       int current=-1;
                       String msg=null;
                       if(splits[0].trim().length()!=0)
                       {
                           current=Integer.parseInt(splits[0]);
                       }
                       if(splits[1].trim().length()!=0)
                       {
                           msg=splits[1].trim();
                       }
                       
                       this.fireProgressStateChanged(msg,current); 
                    }
                }catch(Throwable ex)
                {
                    this.fireProgressStateChanged(
                        "R is working...",
                        -1
                    );
                }
                Thread.sleep(200);
            }
        }catch(InterruptedException ex)
        {
            ex.printStackTrace();
        }
    }
    
    public void setFinished()
    {
        this.finished=true;
        long t=System.currentTimeMillis()-this.settings.getBeginTimeStamp();
        fireProgressStateChanged(
            "R-process finished. (Duration: "+
            RDefaults.getTimeString(t)+
            ")",
            1000
        );
    }
    
    
    public void addProgressStateChangedListener( ProgressStateChangedListener listener )
    {
      eventListenerList.add( ProgressStateChangedListener.class, listener );
    }


    public void removeProgressStateChangedListener( ProgressStateChangedListener listener )
    {
      eventListenerList.remove( ProgressStateChangedListener.class, listener );
    }
 
    
    
    protected void fireProgressStateChanged(String msg, int current)
    {
        if(this.event==null)
        {
            this.event=new ProgressStateEvent(this);            
        }else
        {
            this.event.clearSettings();
        }
        
        this.event.put(ProgressStateEvent.ACTIONS.VALUE,new Integer(current));
        this.event.put(ProgressStateEvent.ACTIONS.MESSAGE,msg);
        
        Object[] listeners = eventListenerList.getListenerList();
        // Process the listeners last to first, notifying
        // those that are interested in this event
        for (int i = listeners.length-2; i>=0; i-=2) 
        {
            if (listeners[i]==ProgressStateChangedListener.class) 
            {
                ((ProgressStateChangedListener)listeners[i+1]).progressStateChanged(event);
            }
        }
        
        
        
    }

    /* (non-Javadoc)
     * @see mayday.core.tasks.TaskFinishedListener#taskFinished(mayday.core.tasks.TaskFinishedEvent)
     */
    public void taskFinished(TaskFinishedEvent arg0)
    {
        this.setFinished();        
    }


}
