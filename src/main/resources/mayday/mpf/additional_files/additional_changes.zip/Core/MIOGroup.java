/*
 * Created on Dec 7, 2004
 *
 */
package mayday.core.mi;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.event.EventListenerList;

import mayday.core.ProbeList;
import mayday.core.ProbeListEvent;
import mayday.core.ProbeListListener;

/**
 * @author gehlenbo
 *
 */
public class MIOGroup< T extends MIOType >
implements MIStructure, Comparable, ProbeListListener
{
  private final Class mioType;
  private final int id;
  private final Date date;
  protected String description;  
  
  private boolean isWriteProtected;
  private String note;
  private MIManager miManager;
  
  // indicates that this group was extracted from a compound MIO group
  private boolean isEmbedded;
  private boolean isFinished;
  
  // if the group is associated with a probe list whose content is changed this
  // will be set to true
  private boolean isInvalid;

  // indicates that this group is a group of compound MIOs
  private boolean isCompound;
  

  private TreeMap< MIOExtendable, T > mioList;
  
  private EventListenerList eventListenerList;
  private MIOGroupEvent mioGroupEvent;


  
  public MIOGroup( MIManager miManager, String description, Class mioType )
  {
    this.miManager = miManager;
    this.id = this.miManager.getNextGroupId();
    this.description = description;
    this.date = new Date();
    this.mioType = mioType;
    this.isFinished = false;
    this.note = new String();
    
    this.mioList = new TreeMap< MIOExtendable, T >();
    
    this.isWriteProtected = false;
    this.isEmbedded = false;
    this.isCompound = MIOUtilities.isRelated( mioType, CompoundMIOType.class );
    this.isInvalid = false;
        
    this.eventListenerList = new EventListenerList();
    this.mioGroupEvent = null;
    
    // 2005-02-05 NG: this now has to be done via finish()
    //miManager.getMIOGroupContainer().add( this );
  }
  
  
  public MIOGroup( MIManager miManager, String description, Class mioType, boolean isEmbedded )
  {
    this( miManager, description, mioType );

    this.isEmbedded = isEmbedded;    
  }
  
  
  public Class getPayloadClass()
  throws Exception
  {
    ArrayList< T > l_mios = new ArrayList< T >( this.mioList.values() );
    
    if ( l_mios.size() > 0 )
    {
      Method l_getValueMethod = l_mios.get( 0 ).getClass().getMethod( "getValue" );
      
      return ( l_getValueMethod.getReturnType() );
    }
    
    return ( null );
  }
  
  
  
  public boolean isFinished()
  {
    return ( this.isFinished );
  }

  
  public void finish()
  {    
    Set l_keys = this.mioList.keySet();
    
    // add MIOs to the MIOExtendable objects
    for ( Object l_extendable : l_keys )
    {
      ((MIOExtendable)l_extendable).getMIContainer().add( this.mioList.get( ((MIOExtendable)l_extendable) ) );
      
      // check whether associated object is a probe list => register MIOGroup as ProbeListListener
      if ( MIOUtilities.isRelated( ((MIOExtendable)l_extendable).getClass(), ProbeList.class ) )
      {        
        ((ProbeList)l_extendable).addProbeListListener( this );
      }
    }
    
    this.isFinished = true;

    // must be declared finished before this is called!!!
   	miManager.add( this );
    
  }  
  
  
  public String getClassName()
  {
    return ( this.mioType.getName() );
  }
  
  public Class getMioClass()
  {
      return mioType;
  }

  
  //060507, fb: added this function to allow addition of MIOs after a group has been finished.
  // See mayday.mpf.MaydayDataObject.makeProperClone(...) as to why this is needed. 
  // This function is modeled on the add(...) function
  public synchronized void addAfterFinishing(MIOExtendable mioExtendable, T mio) throws RuntimeException{
	  boolean finishedStatus = this.isFinished;
	  this.isFinished=false;
	  try {
		  this.add(mioExtendable, mio);
	  } finally {
		  // stay consistent
		  this.isFinished=finishedStatus;
	  }
	  // perform finish() actions
      mioExtendable.getMIContainer().add( mio );
      if ( MIOUtilities.isRelated( mioExtendable.getClass(), ProbeList.class ) )
    	  ((ProbeList)mioExtendable).addProbeListListener( this );
  }

  
  public void add( MIOExtendable mioExtendable, T mio )
  throws RuntimeException
  {   
    if ( isFinished() )
    {
    	this.isFinished=false;
      throw ( new RuntimeException( "This MIO groups has been finished. " +
          "You can't add more MIOs to this group." ) );
    }
    
    if ( !this.mioType.equals( mio.getClass() ) )
    {
      throw ( new RuntimeException( "Class of group (" +
          this.mioType.getName() +
          ") does not equal class of MIO object (" +
          mio.getClass().getName() +
          ")." ) );      
    }
    
    if ( this.mioList.containsKey( mioExtendable ) )
    {
      throw ( new RuntimeException( "Object \"" +
          mioExtendable.getAnnotation().getName() +
          "\" has already been assigned an MIO in this group." ) );      
    }
    
    // these functions will throw runtime exceptions if they have been called before
    // with non-null arguments 
    mio.setGroup( this );
    mio.setObject( mioExtendable );
    
    this.mioList.put( mioExtendable, mio );

    this.addMIOGroupListener( mio );
  }
  
  
  //060507, fb: I need the remove function for memory cleanup in mayday.mpf.MaydayDataObject
  public void remove( T mio )
  throws RuntimeException
  {
    if ( !this.mioType.equals( mio.getClass() ) )
    {
      throw ( new RuntimeException( "Class of group (" +
          this.mioType.getName() +
          ") does not equal class of MIO object (" +
          mio.getClass().getName() +
          ")." ) );      
    }
    
    if ( !this.mioList.containsValue( mio ) )
    {
      throw ( new RuntimeException( "MIO (" + mio.getId() + ") not in group." ) );      
    }
    
    Object[] l_keys = this.mioList.keySet().toArray();
    
    for ( int i = 0; i < l_keys.length; ++i )
    {
      if ( this.mioList.get( l_keys[i] ) == mio  )
      {
        this.mioList.remove( l_keys[i] );
      }
    }
  }
  
  
  public ArrayList< T > getMIOList()
  {
    ArrayList< T > l_temp = new ArrayList< T >();
    l_temp.addAll( this.mioList.values() );
    
    return ( l_temp );
  }
  
  
  public T getMIO( MIOExtendable mioExtendable )
  {
    return ( this.mioList.get( mioExtendable ) );
  }
  
  
  public int getNumberOfMIOs()
  {
    return ( this.mioList.size() );
  }
  
  
  public int getId()
  {
    return ( this.id );
  }
  
  
  public Date getDate()
  {
    return ( this.date );
  }
  
  
  public String getDescription()
  {
    return ( this.description );
  }
  

  public void setDescription( String description )
  {
    if ( !this.description.equals( description ) )
    {
      this.description = description;
      
      fireMIOGroupChanged( MIOGroupEvent.DESCRIPTION_CHANGED );
    }    
  }
  
  
  public MIManager getMIManager()
  {
    return ( this.miManager );
  }
  
  
  public boolean isWriteProtected()
  {
    return ( this.isWriteProtected );
  }
  
  
  public void setWriteProtected( boolean isWriteProtected )
  {
    if ( this.isWriteProtected != isWriteProtected )
    {
      this.isWriteProtected = isWriteProtected;

      fireMIOGroupChanged( MIOGroupEvent.STATUS_CHANGED );      
    }
  }

  
  public boolean isEmbedded()
  {
    return ( this.isEmbedded );
  }


  public boolean isCompound()
  {
    return ( this.isCompound );
  }
  
  
  public boolean isInvalid()
  {
    return ( this.isInvalid );
  }


  public String getNote()
  {
    return ( this.note );
  }

  
  public void setNote( String note )
  {
    if ( !this.note.equals( note ) )
    {
      this.note = note;
      
      fireMIOGroupChanged( MIOGroupEvent.NOTE_CHANGED );
    }    
  }
  
  
  public String toString()
  {
    return ( getDescription() + " [" + getId() + "]" );
  }
  
  
  public int compareTo( Object o )
  {
    MIOGroup group1 = this;
    MIOGroup group2;    

    try
    {
      group2 = (MIOGroup)o;
    }
    catch ( ClassCastException exception )
    {
      return ( -1 );
    }

    if ( group1.getId() < group2.getId() )
    {
      return ( -1 );
    }
    
    if ( group1.getId() > group2.getId() )
    {
      return ( 1 );
    }
    
    return ( 0 );
  }
  
  
  public boolean equals( Object o )
  {
    MIOGroup group1 = this;
    MIOGroup group2;
    
    try
    {
      group2 = (MIOGroup)o;
    }
    catch ( ClassCastException exception )
    {
      return ( false );
    }
    
    return ( group1.getId() == group2.getId() );
  }
  
  
  public void probeListChanged( ProbeListEvent event )
  { 
    if ( ( event.getChange() & ProbeListEvent.CONTENT_CHANGE ) != 0 )
    {
      this.isInvalid = true;      
      
      fireMIOGroupChanged( MIOGroupEvent.STATUS_CHANGED );
    }
    
    if ( ( event.getChange() & ProbeListEvent.PROBELIST_CLOSED ) != 0 )
    {
      this.miManager.remove( this );

      fireMIOGroupChanged( MIOGroupEvent.GROUP_DELETED );

      // remove all mio group listeners
      Object[] l_mios = this.mioList.values().toArray();      
      for ( Object l_object: l_mios )
      {
        this.removeMIOGroupListener( ((MIO)l_object) );
      }
      
      this.mioList.clear();      
    }

  }
  
  
  public void addMIOGroupListener( MIOGroupListener listener )
  {
    eventListenerList.add( MIOGroupListener.class, listener );
  }


  public void removeMIOGroupListener( MIOGroupListener listener )
  {
    eventListenerList.remove( MIOGroupListener.class, listener );
  }


  protected void fireMIOGroupChanged( int change )
  {
    //if ( isSilent() )
    //{
    //  return;
    //}
    
    // guaranteed to return a non-null array
    Object[] l_listeners = this.eventListenerList.getListenerList();
    
    // process the listeners last to first, notifying
    // those that are interested in this event
    for ( int i = l_listeners.length-2; i >= 0; i-=2 )
    {
      if ( l_listeners[i] == MIOGroupListener.class )
      {
        // lazily create the event:
        if ( this.mioGroupEvent == null )
        {
          this.mioGroupEvent = new MIOGroupEvent( this, change );
        }
        ((MIOGroupListener)l_listeners[i+1]).mioGroupChanged( this.mioGroupEvent );
      }
    }
    
    this.mioGroupEvent = null;
  }
}
