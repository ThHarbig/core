package mayday.dataimport.project;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import mayday.core.Probe;
import mayday.core.ProbeList;
import mayday.core.mi.MIOGroup;
import mayday.core.mi.MIOParserNotFoundException;
import mayday.core.mi.MIOType;
import mayday.core.mi.MIOTypeExchangeManager;
import mayday.core.mi.MIOTypeParser;
import mayday.dataimport.snapshot.Snapshot;

/**
 * @author  Stephan Symons
 * Created 19.07.2005
 * 
 * <pre>
 * CREATE TABLE probeMIO<br>
(<br>
    thegroup INT,<br>
    probe VARCHAR(255),<br>
    dataset VARCHAR(255),<br>
    state VARCHAR(255),<br>
    project VARCHAR(255),<br>
    type TEXT,<br>
    payload TEXT,<br>
    PRIMARY KEY (theGroup, Probe, Dataset, State, Project),<br>
    CONSTRAINT FK_probeMIO_1 FOREIGN KEY (thegroup,dataset,state,project)<br>
        REFERENCES probeMioGroup(id,dataset,state,project) ON DELETE CASCADE ON UPDATE CASCADE,<br>
    CONSTRAINT FK_probeMIO_2 FOREIGN KEY (probe,dataset,state,project)<br>
        REFERENCES probe(name,dataset,state,project) ON DELETE CASCADE ON UPDATE CASCADE<br>
<br>
);<br>
 * </pre>
 */
public class ProbeMIO 
{
    private int group;
    private String probe;
    private String dataset;
    private String state;
    private String project;
    private String type;
    private String payload;
    
    /**
     * @return Returns the dataset.
     */
    public String getDataset() 
    {
        return dataset;
    }
    /**
     * @param dataset The dataset to set.
     */
    public void setDataset(String dataset) 
    {
        this.dataset = dataset;
    }
    /**
     * @return Returns the group.
     */
    public int getGroup() 
    {
        return group;
    }
    /**
     * @param group The group to set.
     */
    public void setGroup(int group) 
    {
        this.group = group;
    }
    /**
     * @return Returns the payload.
     */
    public String getPayload() 
    {
        return payload;
    }
    /**
     * @param payload The payload to set.
     */
    public void setPayload(String payload) 
    {
        this.payload = payload;
    }
    /**
     * @return Returns the probe.
     */
    public String getProbe() 
    {
        return probe;
    }
    /**
     * @param probe The probe to set.
     */
    public void setProbe(String probe) 
    {
        this.probe = probe;
    }
    /**
     * @return Returns the project.
     */
    public String getProject() 
    {
        return project;
    }
    /**
     * @param project The project to set.
     */
    public void setProject(String project) 
    {
        this.project = project;
    }
    /**
     * @return Returns the state.
     */
    public String getState() 
    {
        return state;
    }
    /**
     * @param state The state to set.
     */
    public void setState(String state) 
    {
        this.state = state;
    }
    /**
     * @return Returns the type.
     */
    public String getType() 
    {
        return type;
    }
    /**
     * @param type The type to set.
     */
    public void setType(String type) 
    {
        this.type = type;
    }
    
    
    public static boolean batchSubmit(Connection con, List<ProbeMIO> mlist) throws SQLException
    {
        StringBuffer sb=new StringBuffer();
        int i=0;
        Statement st=con.createStatement();
        for(ProbeMIO p:mlist)
        {
           sb.append("INSERT INTO probeMIO(thegroup, probe, dataset, state, project, type, payload)" +
                "VALUES ("+p.group+
                ",'"+p.probe.replaceAll("'","''")   +"'"+
                ",'"+p.dataset.replaceAll("'","''") +"'"+
                ",'"+p.state.replaceAll("'","''")+   "'"+
                ",'"+p.project.replaceAll("'","''") +"'"+
                ",'"+p.type.replaceAll("'","''")+    "'"+
                ",'"+p.payload.replaceAll("'","''")+"');\n");
          if(i%1000==0)
          {
              st.executeUpdate(sb.toString());
              //System.out.println(sb.toString());
              sb=new StringBuffer();
              
          }        
            
        }
        st.executeUpdate(sb.toString());
        st.close();
        
        return true;
    }
    
    public static List<ProbeMIO> parseMIOGroup(ProbeMIOGroup pmg, MIOGroup mg, List<Probe> plist) throws MIOParserNotFoundException
    {
        List<ProbeMIO> res=new ArrayList<ProbeMIO>();
        for(Probe p:plist)
        {
            res.add(new ProbeMIO(mg.getMIO(p), pmg,p));
        }
        
        return res;
    }
    
    public ProbeMIO(MIOType mio, ProbeMIOGroup pmg, Probe p) throws MIOParserNotFoundException
    {
        group=pmg.getId();
        dataset=pmg.getDataset();
        state=pmg.getState();
        project=pmg.getProject();
        type=mio.getClassName();
        probe=p.getAnnotation().getName();
        
        //payload=mio.getValue().toString();
        
        MIOTypeParser parser=MIOTypeExchangeManager.getManager().getParser(
                (Class<? extends MIOType>)mio.getClass()
            );
        payload=parser.asString(mio);
        
        
    }
    

    public ProbeMIO()
    {
        
    }
    
    public ProbeMIO (MIOType mio) throws MIOParserNotFoundException
    {
        type=mio.getClassName();
        if (mio.getObject() instanceof ProbeList) {
        	probe="~PROBELIST~"+((ProbeList)mio.getObject()).getAnnotation().getName();  //fb
        } else {
            probe=((Probe)mio.getObject()).getAnnotation().getName();        	
        }

        MIOTypeParser parser=MIOTypeExchangeManager.getManager().getParser(
                (Class<? extends MIOType>)mio.getClass()
            );
        
        payload=parser.asString(mio);
        
    }
    

        public static final String THIS_TAG="probemio";
        public static final String PROBE_TAG="probe";
        public static final String TYPE_TAG="type";
        
        public static final String PAYLOAD_TAG="payload";
        

        
        public String toXMLString()
        {
            StringBuffer sb=new StringBuffer();
            
            sb.append("<"+THIS_TAG+" " +
                    PROBE_TAG+"= \""+probe+"\" " +
                    TYPE_TAG+"= \""+type+"\">\n");
            
            sb.append("<"+PAYLOAD_TAG+">");
            sb.append(Snapshot.xmlize(payload));
            sb.append("</"+PAYLOAD_TAG+">");
            
            sb.append("</"+THIS_TAG+">\n");
            
            return sb.toString();
        }
        
        
    
    
    
}
