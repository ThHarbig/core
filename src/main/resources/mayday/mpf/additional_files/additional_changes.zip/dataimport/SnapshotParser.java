package mayday.dataimport.snapshot;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mayday.core.Annotation;
import mayday.core.DataMode;
import mayday.core.DataSet;
import mayday.core.MasterTable;
import mayday.core.PluginManager;
import mayday.core.Probe;
import mayday.core.ProbeList;
import mayday.core.ProbeListManager;
import mayday.core.TransformationMode;
import mayday.core.gui.DataSetView;
import mayday.core.mi.MIOExtendable;
import mayday.core.mi.MIOGroup;
import mayday.core.mi.MIOParserNotFoundException;
import mayday.core.mi.MIOType;
import mayday.core.mi.MIOTypeExchangeManager;
import mayday.core.mi.MIOTypeParser;
import mayday.dataimport.project.DBProbe;
import mayday.dataimport.project.Dataset;
import mayday.dataimport.project.Experiment;
import mayday.dataimport.project.ProbeListMIO;
import mayday.dataimport.project.ProbeListMIOGroup;
import mayday.dataimport.project.ProbeMIO;
import mayday.dataimport.project.ProbeMIOGroup;
import mayday.dataimport.project.Probelist;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * @author  Stephan Symons
 * Created 16.12.2005
 * 
 * sigh. xml sucks.
 */
public class SnapshotParser extends DefaultHandler
{

    private boolean datasetAct=false;
    private boolean probeListAct=false;
    private boolean probeAct=false;
    private boolean experimentAct=false;
    
    private boolean probeMioGroupAct=false;
    private boolean probeListMioGroupAct=false;
    private boolean probeMioAct=false;
    private boolean probeListMioAct=false;
    
    private Dataset s_dataset;    
    private Probelist s_probeList;
    private DBProbe s_probe;
    private Experiment s_exp;
    
    private ProbeMIOGroup s_probeMIOGroup;
    private ProbeListMIOGroup s_probeListMIOGroup;
    private ProbeMIO s_probeMIO;
    private ProbeListMIO s_probeListMIO;
    
    private List<DBProbe> s_probes;
    private List<Probelist> s_plists;
    private List<Experiment> s_exps;    
    private List<ProbeMIOGroup> s_p_miosGroups;
    private List<ProbeListMIOGroup> s_l_miosGroups;    

    private String warnings;
    
    
    private MasterTable masterTable;
    
    StringBuffer cBuf=new StringBuffer(); 
    
    /* (non-Javadoc)
     * @see org.xml.sax.ContentHandler#startDocument()
     */
    public void startDocument() throws SAXException
    {
        s_probes=new ArrayList<DBProbe>();
        s_plists=new ArrayList<Probelist>();
        s_exps=new ArrayList<Experiment>();     
        s_p_miosGroups=new ArrayList<ProbeMIOGroup>();
        s_l_miosGroups=new ArrayList<ProbeListMIOGroup>();

    }
    
    /* (non-Javadoc)
     * @see org.xml.sax.ContentHandler#startElement(java.lang.String, java.lang.String, java.lang.String, org.xml.sax.Attributes)
     */
    public void startElement( String namespaceURI, String localName,
            String qName, Attributes atts ) throws SAXException            
            {
        this.cBuf=new StringBuffer();
        //System.out.println( "qName: " + qName );
        
        // Attribute ausgeben
//        for ( int i = 0; i < atts.getLength(); i++ )
//            System.out.println( "Attribut Nr. " + i + ": " +
//                    atts.getQName( i ) + " = " + atts.getValue( i ) );
        if(qName.equals(Experiment.THIS_TAG))
        { 
            s_exp=new Experiment();
            // Attribute ausgeben
            for ( int i = 0; i < atts.getLength(); i++ )
            {
                if(atts.getQName(i).equals(Experiment.NAME_ATT))
                {
                    s_exp.setName(atts.getValue(i));
                }
                
                if(atts.getQName(i).equals(Experiment.NUMBER_ATT))
                {
                    s_exp.setNumber(Integer.parseInt(atts.getValue(i)));
                }
            }
            s_exps.add(s_exp);
        }
        
        if(qName.equals(Dataset.THIS_TAG))
        {            
            s_dataset=new Dataset();
            datasetAct=true;
            
            // Attribute ausgeben
            for ( int i = 0; i < atts.getLength(); i++ )
            {
                if(atts.getQName(i).equals(Dataset.NAME_ATT))
                {
                    s_dataset.setName(atts.getValue(i));
                }
                
                if(atts.getQName(i).equals(Dataset.INFO_ATT))
                {
                    s_dataset.setInfo(atts.getValue(i));
                }
                
                if(atts.getQName(i).equals(Dataset.QUICKINFO_ATT))
                {
                    s_dataset.setQuickInfo(atts.getValue(i));
                }
                
                if(atts.getQName(i).equals(Dataset.NUMEXPS_ATT))
                {
                    s_dataset.setNumexps(Integer.parseInt(atts.getValue(i)));
                }
                
                if(atts.getQName(i).equals(Dataset.NUMPROBES_ATT))
                {
                    s_dataset.setNumprobes(Integer.parseInt(atts.getValue(i)));
                }
            }            
        }
        if(qName.equals(DBProbe.THIS_TAG))
        {
            
            s_probe=new DBProbe();
            probeAct=true;
            
            for ( int i = 0; i < atts.getLength(); i++ )
            {
                if(atts.getQName(i).equals(DBProbe.NAME_ATT))
                {
                    s_probe.setName(atts.getValue(i));
                }
                
                if(atts.getQName(i).equals(DBProbe.INFO_ATT))
                {
                    s_probe.setInfo(atts.getValue(i));
                }
                
                if(atts.getQName(i).equals(DBProbe.QUICKINFO_ATT))
                {
                    s_probe.setQuickInfo(atts.getValue(i));
                }
            }
        }
        if(qName.equals(Probelist.THIS_TAG))
        {            
            s_probeList=new Probelist();
            probeListAct=true;            
            for ( int i = 0; i < atts.getLength(); i++ )
            {
                if(atts.getQName(i).equals(Probelist.NAME_ATT))
                {
                    s_probeList.setName(atts.getValue(i));
                }
                
                if(atts.getQName(i).equals(Probelist.INFO_ATT))
                {
                    s_probeList.setInfo(atts.getValue(i));
                }
                
                if(atts.getQName(i).equals(Probelist.QUICKINFO_ATT))
                {
                    s_probeList.setQuickInfo(atts.getValue(i));
                }
            }
        }
        
        if(qName.equals(ProbeMIOGroup.THIS_TAG))
        {
            s_probeMIOGroup=new ProbeMIOGroup();
            probeMioAct=true;
            for ( int i = 0; i < atts.getLength(); i++ )
            {
         
                if(atts.getQName(i).equals(ProbeMIOGroup.DESCRIPTION_TAG))
                {
                    s_probeMIOGroup.setDescription(atts.getValue(i));
                }
                if(atts.getQName(i).equals(ProbeMIOGroup.EMBEDDED_TAG))
                {
                    s_probeMIOGroup.setEmbedded(Boolean.parseBoolean(atts.getValue(i)));
                }
                if(atts.getQName(i).equals(ProbeMIOGroup.FINISHED_TAG))
                {
                    s_probeMIOGroup.setFinished(Boolean.parseBoolean(atts.getValue(i)));
                }
                if(atts.getQName(i).equals(ProbeMIOGroup.ID_TAG))
                {
                    s_probeMIOGroup.setId(Integer.parseInt(atts.getValue(i)));
                }
                if(atts.getQName(i).equals(ProbeMIOGroup.INVALID_TAG))
                {
                    s_probeMIOGroup.setInvalid(Boolean.parseBoolean(atts.getValue(i)));
                }
                if(atts.getQName(i).equals(ProbeMIOGroup.NOTE_TAG))
                {
                    s_probeMIOGroup.setNote(atts.getValue(i));
                }
                if(atts.getQName(i).equals(ProbeMIOGroup.TYPE_TAG))
                {
                    s_probeMIOGroup.setType(atts.getValue(i));
                }
                if(atts.getQName(i).equals(ProbeMIOGroup.WRITEPROTECTED_TAG))
                {
                    s_probeMIOGroup.setWriteProtected(Boolean.parseBoolean(atts.getValue(i)));
                }
            }
        }
        
        if(qName.equals(ProbeMIO.THIS_TAG))
        {
            s_probeMIO=new ProbeMIO();
            for ( int i = 0; i < atts.getLength(); i++ )
            {
                if(atts.getQName(i).equals(ProbeMIO.PROBE_TAG))
                {
                    s_probeMIO.setProbe(atts.getValue(i));
                }
                if(atts.getQName(i).equals(ProbeMIO.TYPE_TAG))
                {
                    s_probeMIO.setType(atts.getValue(i));
                }
            }
            probeMioAct=true;
        }
        
        if(qName.equals(ProbeListMIOGroup.THIS_TAG))
        {
            s_probeListMIOGroup=new ProbeListMIOGroup();
            probeListMioAct=true;
            for ( int i = 0; i < atts.getLength(); i++ )
            {
         
                if(atts.getQName(i).equals(ProbeListMIOGroup.DESCRIPTION_TAG))
                {
                    s_probeListMIOGroup.setDescription(atts.getValue(i));
                }
                if(atts.getQName(i).equals(ProbeListMIOGroup.EMBEDDED_TAG))
                {
                    s_probeListMIOGroup.setEmbedded(Boolean.parseBoolean(atts.getValue(i)));
                }
                if(atts.getQName(i).equals(ProbeListMIOGroup.FINISHED_TAG))
                {
                    s_probeListMIOGroup.setFinished(Boolean.parseBoolean(atts.getValue(i)));
                }
                if(atts.getQName(i).equals(ProbeListMIOGroup.ID_TAG))
                {
                    s_probeListMIOGroup.setId(Integer.parseInt(atts.getValue(i)));
                }
                if(atts.getQName(i).equals(ProbeListMIOGroup.INVALID_TAG))
                {
                    s_probeListMIOGroup.setInvalid(Boolean.parseBoolean(atts.getValue(i)));
                }
                if(atts.getQName(i).equals(ProbeListMIOGroup.NOTE_TAG))
                {
                    s_probeListMIOGroup.setNote(atts.getValue(i));
                }
                if(atts.getQName(i).equals(ProbeListMIOGroup.TYPE_TAG))
                {
                    s_probeListMIOGroup.setType(atts.getValue(i));
                }
                if(atts.getQName(i).equals(ProbeListMIOGroup.WRITEPROTECTED_TAG))
                {
                    s_probeListMIOGroup.setWriteProtected(Boolean.parseBoolean(atts.getValue(i)));
                }
            }
        }
        
        if(qName.equals(ProbeListMIO.THIS_TAG))
        {
            s_probeListMIO=new ProbeListMIO();
            for ( int i = 0; i < atts.getLength(); i++ )
            {
                if(atts.getQName(i).equals(ProbeListMIO.PROBE_TAG))
                {
                    s_probeListMIO.setProbeList(atts.getValue(i));
                }
                if(atts.getQName(i).equals(ProbeListMIO.TYPE_TAG))
                {
                    s_probeListMIO.setType(atts.getValue(i));
                }
            }
            probeListMioAct=true;
        }
        
        
     }
    
    public void characters( char ch[], int start, int length )
    {
        cBuf.append(ch,start,length);

    }
    
    public void endElement( String namespaceURI, String localName, String qName )
    {        
        //System.out.println( characterBuf.toString()+"!");
        if(datasetAct)
        {                       
            if(qName.equals(Dataset.DATAMODE_TAG))
            {
                s_dataset.setDatamode(Integer.parseInt(cBuf.toString()));
            }
            if(qName.equals(Dataset.TRANSMODE_TAG))
            {
                s_dataset.setTransmode(Integer.parseInt(cBuf.toString()));
            }
            if(qName.equals(Dataset.DATAMODENAME_TAG))
            {
                s_dataset.setDataModeName(cBuf.toString());
            }
            if(qName.equals(Dataset.TRANSMODENAME_TAG))
            {
                s_dataset.setTransModeName(cBuf.toString());
            }
            
            if(qName.equals(Dataset.SILENT_TAG))
            {
                s_dataset.setSilent(Boolean.parseBoolean(cBuf.toString()));
            }
        }
        if(qName.equals(Dataset.THIS_TAG))
        {
            datasetAct=false; 
        }
        
        if(probeAct)
        {
            if(qName.equals(DBProbe.DISPLAYNAME_TAG))
            {
                s_probe.setDisplayName(cBuf.toString());
            }
            if(qName.equals(DBProbe.VALUES_TAG))
            {
                s_probe.setValues(DBProbe.string2Array(cBuf.toString()));
            }
            
        }
        if(qName.equals(DBProbe.THIS_TAG))
        {
            s_probes.add(s_probe);
            probeAct=false;
        }

        if(probeListAct)
        {
            if(qName.equals(Probelist.COLOR_TAG))
            {
                s_probeList.setColor(Integer.parseInt(cBuf.toString()));                
            }
            if(qName.equals(Probelist.PROBEREF_TAG))
            {
                s_probeList.addProbeRef(cBuf.toString());
            }
        }
        
        if(qName.equals(Probelist.THIS_TAG))
        {
            s_plists.add(s_probeList);
            probeListAct=false;
        }
        
        if(qName.equals(ProbeMIOGroup.THIS_TAG))
        {
            s_p_miosGroups.add(s_probeMIOGroup);
            System.out.println(s_probeMIOGroup.numMIOs());
            probeMioAct=false;
        }

        if(qName.equals(ProbeMIO.THIS_TAG))
        {
            s_probeMIOGroup.addMIO(s_probeMIO);
            probeMioAct=false;
        }
        
        if(probeMioAct)
        {
            if(qName.equals(ProbeMIO.PAYLOAD_TAG))
            {
                s_probeMIO.setPayload(Snapshot.unxmlize(cBuf.toString()));
            }
            
        }
        
        if(qName.equals(ProbeListMIOGroup.THIS_TAG))
        {
            s_l_miosGroups.add(s_probeListMIOGroup);
            System.out.println(s_probeListMIOGroup.numMIOs());
            probeListMioAct=false;
        }
        
        if(qName.equals(ProbeListMIO.THIS_TAG))
        {
            s_probeListMIOGroup.addMIO(s_probeListMIO);
            probeListMioAct=false;
        }
        
        if(probeListMioAct)
        {
            if(qName.equals(ProbeListMIO.PAYLOAD_TAG))
            {
                s_probeListMIO.setPayload(Snapshot.unxmlize(cBuf.toString()));
            }
            
        }
    }
    
    public void endDocument()
    {
//        System.out.println(s_exps.size());
//        System.out.println(s_probes.size());
//        System.out.println(s_plists.size());
//        System.out.println(s_plists.get(0).getProbeRef(0));
//        System.out.println( "Ende des Dokuments" );
        
        //build dataset:
        DataSet datas=new DataSet();
        MasterTable mt = new MasterTable(datas);
        mt.setNumberOfExperiments(s_dataset.getNumexps());
        
        DataSetView dsv=new DataSetView(datas);
        ProbeListManager listman = datas.getProbeListManager();
        
        datas.setAnnotation(new Annotation(s_dataset.getName(),s_dataset.getQuickInfo(),s_dataset.getInfo()));
        datas.setSilent(s_dataset.isSilent());
        //experiments:
        for(Experiment e:s_exps)
        {
            mt.setExperimentName(e.getNumber(),e.getName());
        }
        for(DBProbe p:s_probes)
        {
            Probe pr=new Probe(mt);
            pr.setAnnotation(new Annotation(p.getName(), p.getQuickInfo(), p.getInfo()));
            for(int i=0; i!= p.getValues().length; ++i)
            {
                if(Double.isNaN(p.getValues()[i]))
                {                  
                    pr.addExperiment(null);                    
                }else
                {
                    pr.addExperiment(p.getValues()[i]);
                }
            } 
            mt.addProbe(pr);
        }
        Map<String,ProbeList> plmap=new HashMap<String,ProbeList>();
        for(Probelist pl:s_plists)
        {
            ProbeList plist=new ProbeList(datas,true);
            plist.setAnnotation(new Annotation(pl.getName(), pl.getQuickInfo(), pl.getInfo()));
            plist.setColor(new Color(pl.getColor()));
            
            for(int i=0; i!=pl.getNumProbeRef(); ++i)
            {
                plist.addProbe(mt.getProbe(pl.getProbeRef(i)));
            }
            plist.setDataSet(datas);
            datas.getProbeListManager().addObject(plist);
            
            plmap.put(pl.getName(), plist);
            
        }
        
        for(ProbeMIOGroup pmg:s_p_miosGroups)
        {
            String type=pmg.getType();
            String descr=pmg.getDescription();
            try{
            //fetch a plugin manager
            PluginManager plm=PluginManager.getInstance();
            
            //create a mio group.
            Object o = PluginManager.getInstance().classForName(pmg.getType());
            MIOGroup mgroup =new MIOGroup(
                    datas.getMIManager(),
                    pmg.getDescription(), 
                    //(Class<MIOType>)(PluginManager.getInstance().classForName(type))
                    (Class<MIOType>)o
                    );
            mgroup.setNote(pmg.getNote());
            
            //fetch mios:
            System.out.println(pmg.numMIOs());
            for(int i=0; i!= pmg.numMIOs(); ++i)
            {
                Object o2 =PluginManager.getInstance().classForName(pmg.getMIO(i).getType());
                
                MIOTypeParser parser=
                    MIOTypeExchangeManager.getManager().getParser(
                            //(Class<MIOType>)PluginManager.getInstance().classForName(mtype)
                            (Class<MIOType>)o2
                            );
               
                
                String payload = pmg.getMIO(i).getPayload();
                String probename = pmg.getMIO(i).getProbe();
                
                MIOExtendable probe=null;
                
                if (probename.startsWith("~PROBELIST~")) {  //fb
                	probename = probename.replace("~PROBELIST~","");
                	for (Object obbl : mt.getDataSet().getProbeListManager().getObjects()) {
                		if (((ProbeList)obbl).getAnnotation().getName().equals(probename))
                			probe = (ProbeList)obbl;
                		break;
                	}
                } else {
                	probe = mt.getProbe(pmg.getMIO(i).getProbe());
                }
                
                mgroup.add(
                probe,
                parser.parse(datas.getMIManager(), pmg.getMIO(i).getPayload())
                );
                
                
            }
            mgroup.finish();
            
            }catch(MIOParserNotFoundException e)
            {
                //sarcasm.
                // schoen. klappt nicht. 
                //e.printStackTrace();
                warnings=warnings+"No MIOType parser found for: "+type+" ("+descr+"). Skipped.\n";
                continue;
            }catch(Exception e)
            {
                
            }
            
        }
        

        for(ProbeListMIOGroup pmg:s_l_miosGroups)
        {
            String type=pmg.getType();
            String descr=pmg.getDescription();
            try{
            //fetch a plugin manager
            PluginManager plm=PluginManager.getInstance();
            
            //create a mio group.
            Object o = PluginManager.getInstance().classForName(pmg.getType());
            MIOGroup mgroup =new MIOGroup(
                    datas.getMIManager(),
                    pmg.getDescription(), 
                    //(Class<MIOType>)(PluginManager.getInstance().classForName(type))
                    (Class<MIOType>)o
                    );
            mgroup.setNote(pmg.getNote());
            
            //fetch mios:
            System.out.println(pmg.numMIOs());
            
            //find probelist:
            

            
            for(int i=0; i!= pmg.numMIOs(); ++i)
            {
                Object o2 =PluginManager.getInstance().classForName(pmg.getMIO(i).getType());
                
                MIOTypeParser parser=
                    MIOTypeExchangeManager.getManager().getParser(
                            //(Class<MIOType>)PluginManager.getInstance().classForName(mtype)
                            (Class<MIOType>)o2
                            );
               
                
                
                mgroup.add(
                        
                plmap.get(pmg.getMIO(i).getProbeList()),
                parser.parse(datas.getMIManager(), pmg.getMIO(i).getPayload())
                );
                
                
            }
            mgroup.finish();
            
            }catch(MIOParserNotFoundException e)
            {
                //sarcasm.
                // schoen. klappt nicht. 
                //e.printStackTrace();
                warnings=warnings+"No MIOType parser found for: "+type+" ("+descr+"). Skipped.\n";
                continue;
            }catch(Exception e)
            {
                
            }
            
        }
        

        
        mt.setDataMode(new DataMode(s_dataset.getDataModeName(), s_dataset.getDatamode()));
        mt.setTransformationMode(new TransformationMode(s_dataset.getTransModeName(),
                s_dataset.getTransmode()));
        datas.setMasterTable(mt);
        mt.setDataSet(datas); 
        
        masterTable.getDataSet().getDataSetView().getDataSetManagerView().addDataSetView(dsv);
        
    }

    public MasterTable getMasterTable() {
        return masterTable;
    }

    public void setMasterTable(MasterTable masterTable) {
        this.masterTable = masterTable;
    }

    public String getWarnings() {
        return warnings;
    }

    public void setWarnings(String warnings) {
        this.warnings = warnings;
    }
    
    
    
}
